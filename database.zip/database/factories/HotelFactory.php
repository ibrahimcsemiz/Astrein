<?php

namespace Database\Factories;

use App\Models\City;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class HotelFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $managers = User::select('id', 'function')->where('function', 'Manager')->get();
        $foremans = User::select('id', 'function')->where('function', 'Foreman')->get();
        $cities = City::select('id')->get();
        return [
            'name' => $this->faker->company(),
            'email' => $this->faker->companyEmail(),
            'telephone' => $this->faker->phoneNumber(),
            'related_person' => $this->faker->name(),
            'city_id' => $this->faker->randomElement($cities),
            'address' => $this->faker->address(),
            'foreman' => $this->faker->randomElement($foremans),
            'manager' => $this->faker->randomElement($managers),
        ];
    }
}
