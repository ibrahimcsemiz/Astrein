<?php

namespace Database\Seeders;

use App\Models\City;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

class CitiesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $file = Storage::disk('local')->get('json/germany.json');
        $json = json_decode($file);

        foreach ($json as $city => $state) {
            City::create([
                    'name' => $city,
                    'state' => $state
                ]
            );
        }
    }
}
