<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(928)->create();
        // \App\Models\Hotel::factory(486)->create();
        // \App\Models\Relationship::factory(2476)->create();
    }
}
